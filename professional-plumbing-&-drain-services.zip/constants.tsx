
import React from 'react';
import { Droplet, Waves, Wrench, Thermometer, ShieldCheck, Flame } from 'lucide-react';

export const BRAND = {
  name: "PROPLUMB",
  phone: "(800) 555-0199",
  email: "emergency@proplumb-local.com",
  address: "123 Main Street, Suite 500, Metro City, ST 12345",
  city: "Metro City",
  yearsInBusiness: "20+",
};

export const SERVICES = [
  {
    id: 'drain-cleaning',
    title: "Drain Cleaning",
    description: "Expert removal of stubborn blockages and root intrusions using high-pressure hydro-jetting.",
    icon: <Droplet className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 'emergency-repairs',
    title: "24/7 Emergency Repairs",
    description: "Burst pipes, flooding, or sewage backups. We respond within 60 minutes, day or night.",
    icon: <Flame className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 'water-heaters',
    title: "Water Heaters",
    description: "Installation, repair, and maintenance for tankless and traditional water heating systems.",
    icon: <Thermometer className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1585704032915-c3400ca1f963?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 'pipe-inspection',
    title: "CCTV Pipe Inspection",
    description: "State-of-the-art camera tech to locate leaks and structural issues without digging.",
    icon: <Waves className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1590479773265-7464e5d48118?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 'gas-lines',
    title: "Gas Line Service",
    description: "Certified gas fitting for stoves, fireplaces, and outdoor grills. Safety is our priority.",
    icon: <Wrench className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1542013936693-884638332954?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 're-piping',
    title: "Full Re-Piping",
    description: "Modernizing older homes with durable, leak-proof PEX or copper piping systems.",
    icon: <ShieldCheck className="w-8 h-8 text-red-600" />,
    image: "https://images.unsplash.com/photo-1517646281552-6265176d339d?q=80&w=800&auto=format&fit=crop"
  }
];

export const BLOG_POSTS = [
  {
    id: '1',
    title: "5 Signs Your Main Sewer Line is Clogged",
    excerpt: "Don't wait for a backup! Learn the early warning signs of a serious sewer line issue.",
    date: "May 15, 2024",
    author: "Mike Thompson",
    image: "https://images.unsplash.com/photo-1517646281552-6265176d339d?q=80&w=400&auto=format&fit=crop",
    category: "Maintenance"
  },
  {
    id: '2',
    title: "Tankless vs. Traditional Water Heaters",
    excerpt: "Which one is right for your home? We break down costs, efficiency, and longevity.",
    date: "April 22, 2024",
    author: "Sarah Jenkins",
    image: "https://images.unsplash.com/photo-1585704032915-c3400ca1f963?q=80&w=400&auto=format&fit=crop",
    category: "Upgrades"
  },
  {
    id: '3',
    title: "Emergency Steps During a Burst Pipe",
    excerpt: "A step-by-step guide to minimizing water damage while you wait for our emergency plumber.",
    date: "March 10, 2024",
    author: "Dave Richards",
    image: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=400&auto=format&fit=crop",
    category: "Safety"
  }
];
