
import React from 'react';
import { Shield, PhoneCall, Award, Clock, Star, MapPin, ChevronRight, CheckCircle2 } from 'lucide-react';
import { BRAND, SERVICES, BLOG_POSTS } from '../constants';
import { Button } from '../components/Button';
import { ContactForm } from '../components/ContactForm';
import { Link } from 'react-router-dom';

export const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white pt-16 pb-24 md:pt-32 md:pb-48 overflow-hidden">
        {/* Background Image Overlay */}
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1581244277943-fe4a9c777189?q=80&w=2000&auto=format&fit=crop" 
            alt="Plumber at work" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 bg-red-600 px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest mb-6">
                <Clock size={14} /> Available 24/7 For Emergencies
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-black mb-6 leading-tight">
                Trusted Emergency <span className="text-red-600">Plumbers</span> in {BRAND.city}
              </h1>
              <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl leading-relaxed">
                Fast, professional, and licensed plumbers ready to fix your pipes, drains, and water heaters today. We arrive within 60 minutes for emergencies.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Button size="lg" className="shadow-2xl shadow-red-900/40" onClick={() => window.location.href = `tel:${BRAND.phone}`}>
                  <PhoneCall className="mr-2" size={20} /> Call Now: {BRAND.phone}
                </Button>
                <Button variant="outline" size="lg" className="bg-white/10 text-white border-white hover:bg-white/20" onClick={() => document.getElementById('quote-form')?.scrollIntoView()}>
                  Request A Quote
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-white/10">
                <div className="flex items-center gap-3">
                  <Award className="text-red-500" size={32} />
                  <span className="text-sm font-bold uppercase leading-tight">{BRAND.yearsInBusiness} Years Experience</span>
                </div>
                <div className="flex items-center gap-3">
                  <Shield className="text-red-500" size={32} />
                  <span className="text-sm font-bold uppercase leading-tight">Licensed & Insured</span>
                </div>
                <div className="flex items-center gap-3">
                  <Star className="text-red-500" size={32} />
                  <span className="text-sm font-bold uppercase leading-tight">5-Star Rated Service</span>
                </div>
              </div>
            </div>

            <div id="quote-form" className="lg:col-span-5 hidden lg:block">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Trust Bar (Certifications) */}
      <section className="bg-white py-8 border-b border-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center gap-8 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
            <div className="text-2xl font-black text-slate-800 italic">BBB ACCREDITED</div>
            <div className="text-2xl font-black text-slate-800 italic">HOMEADVISOR TOP RATED</div>
            <div className="text-2xl font-black text-slate-800 italic">MASTER PLUMBER CERTIFIED</div>
            <div className="text-2xl font-black text-slate-800 italic">ANGI LIST WINNER</div>
          </div>
        </div>
      </section>

      {/* Mobile Contact Form Preview */}
      <section className="lg:hidden py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <ContactForm />
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h4 className="text-red-600 font-black uppercase tracking-widest text-sm mb-2">Expert Solutions</h4>
            <h2 className="text-4xl md:text-5xl font-black mb-6 uppercase">Our Plumbing Services</h2>
            <p className="text-gray-600 text-lg">
              From minor leaks to major industrial pipe failures, our master plumbers have the tools and expertise to get it right the first time.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES.map((service) => (
              <div key={service.id} className="group bg-gray-50 rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100">
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4 bg-white p-2 rounded shadow-lg">
                    {service.icon}
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-black mb-4 uppercase">{service.title}</h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                  <Link to="/services" className="inline-flex items-center text-red-600 font-bold uppercase tracking-wide hover:gap-2 transition-all">
                    View Details <ChevronRight size={18} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <Button size="lg" variant="secondary" onClick={() => window.location.href = '#/services'}>
              See All Plumbing Services
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-red-600 skew-x-12 translate-x-32 hidden lg:block opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h4 className="text-red-500 font-black uppercase tracking-widest text-sm mb-2">The {BRAND.name} Difference</h4>
              <h2 className="text-4xl md:text-5xl font-black mb-8 uppercase leading-tight">Why Property Owners Trust Us for 20+ Years</h2>
              
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-red-600 rounded flex-shrink-0 flex items-center justify-center font-black text-xl">01</div>
                  <div>
                    <h3 className="text-xl font-bold uppercase mb-2">Upfront Fixed Pricing</h3>
                    <p className="text-gray-400">No hidden fees or surprise charges. You know the exact cost before we turn a single wrench.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-red-600 rounded flex-shrink-0 flex items-center justify-center font-black text-xl">02</div>
                  <div>
                    <h3 className="text-xl font-bold uppercase mb-2">Licensed Master Plumbers</h3>
                    <p className="text-gray-400">We don't send handymen. Only background-checked, certified professionals enter your home.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-red-600 rounded flex-shrink-0 flex items-center justify-center font-black text-xl">03</div>
                  <div>
                    <h3 className="text-xl font-bold uppercase mb-2">Satisfaction Guaranteed</h3>
                    <p className="text-gray-400">If the job isn't done right, we'll return and fix it for free. Your peace of mind is our priority.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-square bg-slate-800 rounded-2xl overflow-hidden border-8 border-slate-700">
                <img 
                  src="https://images.unsplash.com/photo-1542013936693-884638332954?q=80&w=800&auto=format&fit=crop" 
                  alt="Quality Plumbing Tools" 
                  className="w-full h-full object-cover opacity-75"
                />
              </div>
              <div className="absolute -bottom-8 -left-8 bg-red-600 p-8 rounded-xl shadow-2xl">
                <span className="block text-4xl font-black text-white leading-none">24/7</span>
                <span className="block text-xs font-bold uppercase tracking-widest text-white mt-1">EMERGENCY DISPATCH</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black uppercase mb-4">What Our Clients Say</h2>
            <div className="flex justify-center gap-1 mb-4">
              {[1, 2, 3, 4, 5].map((s) => <Star key={s} className="fill-yellow-400 text-yellow-400" />)}
            </div>
            <p className="text-gray-600 font-bold uppercase tracking-wide">Rated 4.9/5 by 500+ Local Customers</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm border border-gray-100">
              <p className="text-gray-700 italic mb-6">"Had a burst pipe at 3 AM. Called ProPlumb and Mike arrived within 45 minutes. Fixed it fast and didn't charge an arm and a leg. Life savers!"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center font-bold text-slate-600">RH</div>
                <div>
                  <h4 className="font-black uppercase">Robert Harris</h4>
                  <p className="text-xs font-bold text-red-600 uppercase">Homeowner, {BRAND.city}</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm border border-gray-100 scale-105 border-t-4 border-red-600 relative z-10">
              <p className="text-gray-700 italic mb-6">"Clean, professional, and on time. They explained everything clearly and gave me a fair price before starting. Highly recommend for any drain cleaning."</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center font-bold text-slate-600">LM</div>
                <div>
                  <h4 className="font-black uppercase">Linda Miller</h4>
                  <p className="text-xs font-bold text-red-600 uppercase">Business Owner, Metro North</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm border border-gray-100">
              <p className="text-gray-700 italic mb-6">"Best plumbing service I've ever used. They replaced my water heater the same day I called. Very efficient and left the place spotless."</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center font-bold text-slate-600">ST</div>
                <div>
                  <h4 className="font-black uppercase">Steven Taylor</h4>
                  <p className="text-xs font-bold text-red-600 uppercase">Property Manager</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Area Section */}
      <section className="py-20 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-slate-300 w-full h-[400px] rounded-2xl flex items-center justify-center text-slate-500 font-bold uppercase relative overflow-hidden grayscale">
                <img src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?q=80&w=1200&auto=format&fit=crop" className="w-full h-full object-cover opacity-50" />
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="bg-red-600/90 text-white p-6 rounded-xl text-center">
                     <MapPin className="mx-auto mb-2" size={40} />
                     <span className="block text-2xl font-black">WE ARE HERE</span>
                   </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h4 className="text-red-600 font-black uppercase tracking-widest text-sm mb-2">Our Reach</h4>
              <h2 className="text-4xl font-black mb-6 uppercase">Serving {BRAND.city} & Beyond</h2>
              <p className="text-gray-600 text-lg mb-8">
                We have dedicated service trucks stationed across the region to ensure rapid response times. If you are in our service area, we can usually be at your door within the hour.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                {['Downtown Metro', 'Northern Suburbs', 'West End', 'South Riverside', 'Highland Park', 'East Industrial'].map((area) => (
                  <div key={area} className="flex items-center gap-2 font-bold uppercase text-slate-700">
                    <CheckCircle2 size={18} className="text-red-600" /> {area}
                  </div>
                ))}
              </div>
              
              <div className="mt-10 p-6 bg-white rounded-lg shadow-sm border border-gray-200">
                <p className="font-bold text-slate-800 mb-2">Not sure if we cover your area?</p>
                <a href={`tel:${BRAND.phone}`} className="text-2xl font-black text-red-600 hover:underline">{BRAND.phone}</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Preview */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="max-w-xl">
              <h2 className="text-4xl font-black uppercase mb-4">Latest Plumbing News</h2>
              <p className="text-gray-600">Expert tips for homeowners and business owners on maintaining their plumbing systems and reducing utility costs.</p>
            </div>
            <Link to="/news">
              <Button variant="outline">View All Articles</Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post) => (
              <div key={post.id} className="group cursor-pointer">
                <div className="h-60 overflow-hidden rounded-xl mb-6 shadow-md relative">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-4 left-4 bg-red-600 text-white text-[10px] font-black px-3 py-1 uppercase rounded-full">
                    {post.category}
                  </div>
                </div>
                <h3 className="text-xl font-black uppercase mb-3 group-hover:text-red-600 transition-colors leading-tight">
                  {post.title}
                </h3>
                <p className="text-gray-500 text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                <Link to={`/news`} className="text-xs font-black uppercase tracking-widest text-slate-900 border-b-2 border-red-600 pb-1 inline-block">Read More</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-16 bg-red-600 text-white text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        <div className="container mx-auto px-4 relative z-10">
          <h2 className="text-3xl md:text-5xl font-black uppercase mb-6 leading-tight">Need Help Right Now?</h2>
          <p className="text-xl font-bold uppercase mb-10 tracking-wide opacity-90">Don't Wait For The Water To Rise. Call The Experts.</p>
          <div className="flex flex-col md:flex-row justify-center gap-6">
            <a href={`tel:${BRAND.phone}`} className="bg-white text-red-600 px-8 py-5 rounded font-black text-2xl md:text-3xl uppercase shadow-2xl hover:bg-slate-900 hover:text-white transition-all">
              {BRAND.phone}
            </a>
            <Button variant="secondary" size="lg" className="border-2 border-white" onClick={() => window.location.href = '#/contact'}>
              Send Online Request
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};
