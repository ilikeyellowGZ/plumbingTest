
import React from 'react';
import { BRAND } from '../constants';
import { Award, Users, ShieldCheck, Heart } from 'lucide-react';
import { Button } from '../components/Button';

export const About: React.FC = () => {
  return (
    <div>
      <section className="bg-slate-900 text-white py-20 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-7xl font-black uppercase mb-6">About Us</h1>
          <p className="text-xl text-gray-400 max-w-2xl uppercase font-bold tracking-wide">Family Owned & Operated Since 2004</p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-black uppercase mb-8 leading-tight">The {BRAND.name} Story</h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Founded on the principles of honesty and technical excellence, {BRAND.name} started as a single truck operation in {BRAND.city}. Our founder, a master plumber with a vision, believed that property owners deserved a more reliable service than what was available.
              </p>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                Today, we operate a fleet of modern service vehicles, yet we maintain that small-business commitment to our neighbors. We don't just fix pipes; we protect your home and business infrastructure.
              </p>
              
              <div className="grid grid-cols-2 gap-8">
                <div className="text-center p-6 bg-gray-50 rounded-xl">
                  <div className="text-4xl font-black text-red-600 mb-2">20+</div>
                  <div className="text-xs font-black uppercase tracking-widest text-gray-500">Years Experience</div>
                </div>
                <div className="text-center p-6 bg-gray-50 rounded-xl">
                  <div className="text-4xl font-black text-red-600 mb-2">15k+</div>
                  <div className="text-xs font-black uppercase tracking-widest text-gray-500">Jobs Completed</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img src="https://images.unsplash.com/photo-1590479773265-7464e5d48118?q=80&w=1200&auto=format&fit=crop" alt="Team working" className="w-full h-[500px] object-cover rounded-3xl shadow-2xl" />
              <div className="absolute -bottom-8 -left-8 bg-slate-900 text-white p-10 rounded-2xl hidden md:block border-l-8 border-red-600 shadow-2xl">
                <blockquote className="italic text-xl mb-4">"We treat every home like it's our own mother's."</blockquote>
                <p className="font-black uppercase text-red-500">— Chief Engineer</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black uppercase mb-4">Our Core Values</h2>
            <div className="w-24 h-2 bg-red-600 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            {[
              { title: "Integrity", icon: <Award size={48} className="text-red-600" />, desc: "Honest assessments and fair pricing every time." },
              { title: "Craftsmanship", icon: <ShieldCheck size={48} className="text-red-600" />, desc: "We take pride in technical perfection." },
              { title: "Speed", icon: <Users size={48} className="text-red-600" />, desc: "We understand that time is of the essence." },
              { title: "Community", icon: <Heart size={48} className="text-red-600" />, desc: "Supporting local charities and initiatives." }
            ].map((v) => (
              <div key={v.title} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-center mb-6">{v.icon}</div>
                <h3 className="text-xl font-black uppercase mb-4">{v.title}</h3>
                <p className="text-gray-500">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-black uppercase mb-8">Ready to Work with the Best?</h2>
          <Button size="lg" onClick={() => window.location.href = '#/contact'}>Join Our Team or Book Service</Button>
        </div>
      </section>
    </div>
  );
};
