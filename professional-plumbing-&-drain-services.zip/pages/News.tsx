
import React from 'react';
import { BLOG_POSTS, BRAND } from '../constants';
import { Button } from '../components/Button';
import { Link } from 'react-router-dom';
import { Calendar, User, Tag } from 'lucide-react';

export const News: React.FC = () => {
  return (
    <div>
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-black uppercase mb-6">Plumbing News & Tips</h1>
          <p className="text-xl text-gray-400 max-w-2xl uppercase font-bold tracking-wide">Stay informed and keep your home protected.</p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-8 space-y-16">
              {BLOG_POSTS.map((post) => (
                <article key={post.id} className="group">
                  <div className="h-[400px] overflow-hidden rounded-2xl shadow-xl mb-8 relative">
                    <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute bottom-6 left-6 flex gap-4">
                      <span className="bg-red-600 text-white text-xs font-black uppercase px-4 py-2 rounded shadow-lg flex items-center gap-2">
                        <Tag size={12} /> {post.category}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 text-gray-400 text-sm font-bold uppercase mb-4">
                    <span className="flex items-center gap-1"><Calendar size={14} /> {post.date}</span>
                    <span className="flex items-center gap-1"><User size={14} /> By {post.author}</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-black uppercase mb-4 group-hover:text-red-600 transition-colors leading-tight">
                    {post.title}
                  </h2>
                  <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                    {post.excerpt} Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...
                  </p>
                  <Button variant="outline">Read Full Article</Button>
                </article>
              ))}
            </div>

            {/* Sidebar */}
            <aside className="lg:col-span-4 space-y-12">
              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-black uppercase mb-6 border-l-4 border-red-600 pl-4">Search Articles</h3>
                <div className="relative">
                  <input type="text" placeholder="Search keywords..." className="w-full px-4 py-3 bg-white border border-gray-200 rounded focus:ring-2 focus:ring-red-600 focus:outline-none" />
                </div>
              </div>

              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-black uppercase mb-6 border-l-4 border-red-600 pl-4">Categories</h3>
                <ul className="space-y-4 font-bold uppercase text-slate-700">
                  {['Maintenance', 'Emergency Service', 'Home Improvement', 'Cost Guides', 'Commercial Tips'].map((cat) => (
                    <li key={cat} className="flex justify-between items-center hover:text-red-600 cursor-pointer transition-colors group">
                      <span>{cat}</span>
                      <span className="bg-white px-2 py-1 rounded text-[10px] text-gray-400 group-hover:bg-red-600 group-hover:text-white">12</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-red-600 p-8 rounded-2xl text-white">
                <h3 className="text-2xl font-black uppercase mb-4">Need Advice?</h3>
                <p className="mb-6 font-bold text-red-100 uppercase text-xs tracking-wider">Our engineers are standing by</p>
                <p className="mb-8 opacity-90">Give us a call and we'll help you diagnose your plumbing issue over the phone for free.</p>
                <a href={`tel:${BRAND.phone}`} className="block text-center bg-slate-900 text-white font-black py-4 rounded uppercase tracking-widest hover:bg-white hover:text-red-600 transition-all">
                  {BRAND.phone}
                </a>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};
