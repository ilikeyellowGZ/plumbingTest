
import React from 'react';
import { SERVICES, BRAND } from '../constants';
import { Button } from '../components/Button';
import { CheckCircle, PhoneCall, ArrowRight } from 'lucide-react';

export const Services: React.FC = () => {
  return (
    <div>
      <section className="bg-slate-900 text-white py-20 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-7xl font-black uppercase mb-6">Our Services</h1>
          <p className="text-xl text-gray-400 max-w-2xl uppercase font-bold tracking-wide">Professional Grade Solutions for Every Plumbing Challenge</p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 gap-24">
            {SERVICES.map((service, index) => (
              <div key={service.id} className={`flex flex-col lg:flex-row gap-12 items-center ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2">
                  <div className="relative">
                    <img src={service.image} alt={service.title} className="w-full h-[400px] object-cover rounded-2xl shadow-2xl" />
                    <div className="absolute -bottom-6 -right-6 bg-red-600 p-6 rounded-xl shadow-xl hidden md:block">
                      {React.cloneElement(service.icon as React.ReactElement, { className: "w-12 h-12 text-white" })}
                    </div>
                  </div>
                </div>
                <div className="lg:w-1/2">
                  <h2 className="text-4xl font-black uppercase mb-6 leading-tight border-b-4 border-red-600 inline-block">{service.title}</h2>
                  <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                    {service.description} Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
                    {['Free Inspection', 'Warranty Included', 'Same Day Service', 'Licensed Techs'].map((item) => (
                      <div key={item} className="flex items-center gap-3 font-bold uppercase text-slate-800">
                        <CheckCircle size={20} className="text-red-600" /> {item}
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-4">
                    <Button onClick={() => window.location.href = `tel:${BRAND.phone}`}>Call Now</Button>
                    <Button variant="outline" onClick={() => window.location.href = '#/contact'}>Get Quote</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Commercial Banner */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-slate-900 rounded-3xl p-8 md:p-16 flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-2/3">
              <h2 className="text-3xl md:text-5xl font-black text-white uppercase mb-6">Need Commercial Service?</h2>
              <p className="text-gray-400 text-lg mb-8">We provide priority maintenance and emergency repairs for restaurants, hotels, hospitals, and industrial facilities in {BRAND.city}.</p>
              <Button size="lg" className="bg-white text-slate-900 hover:bg-gray-100">Contact Commercial Team</Button>
            </div>
            <div className="md:w-1/3 flex justify-center">
              <div className="w-48 h-48 border-8 border-red-600 rounded-full flex items-center justify-center text-center p-4">
                <span className="text-white font-black uppercase text-xl leading-tight">Priority Response</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
