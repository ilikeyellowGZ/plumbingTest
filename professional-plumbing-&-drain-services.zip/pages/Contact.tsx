
import React from 'react';
import { BRAND } from '../constants';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { ContactForm } from '../components/ContactForm';

export const Contact: React.FC = () => {
  return (
    <div>
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-black uppercase mb-6">Get in Touch</h1>
          <p className="text-xl text-gray-400 max-w-2xl uppercase font-bold tracking-wide">Quick Support & Reliable Service Appointments</p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            {/* Info */}
            <div className="lg:col-span-5 space-y-12">
              <div>
                <h2 className="text-4xl font-black uppercase mb-8">Contact Information</h2>
                <div className="space-y-8">
                  <div className="flex gap-6 items-start">
                    <div className="w-14 h-14 bg-red-600 rounded flex items-center justify-center flex-shrink-0 shadow-lg text-white">
                      <Phone size={24} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Emergency Dispatch</h4>
                      <a href={`tel:${BRAND.phone}`} className="text-3xl font-black text-slate-900 hover:text-red-600 transition-colors">{BRAND.phone}</a>
                    </div>
                  </div>
                  
                  <div className="flex gap-6 items-start">
                    <div className="w-14 h-14 bg-slate-900 rounded flex items-center justify-center flex-shrink-0 shadow-lg text-white">
                      <Mail size={24} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Send An Email</h4>
                      <a href={`mailto:${BRAND.email}`} className="text-xl font-bold text-slate-900 hover:text-red-600 transition-colors">{BRAND.email}</a>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <div className="w-14 h-14 bg-slate-900 rounded flex items-center justify-center flex-shrink-0 shadow-lg text-white">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Our Location</h4>
                      <p className="text-xl font-bold text-slate-900">{BRAND.address}</p>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <div className="w-14 h-14 bg-slate-900 rounded flex items-center justify-center flex-shrink-0 shadow-lg text-white">
                      <Clock size={24} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Office Hours</h4>
                      <p className="text-xl font-bold text-slate-900 uppercase">Mon-Sun: 24/7 Service</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-black uppercase mb-4">Area of Service</h3>
                <p className="text-gray-500 mb-4">We serve all of {BRAND.city} and the surrounding 50-mile radius. Including:</p>
                <div className="grid grid-cols-2 gap-2 text-sm font-bold uppercase text-slate-700">
                  <div className="flex items-center gap-2">✓ Metro Center</div>
                  <div className="flex items-center gap-2">✓ Riverside</div>
                  <div className="flex items-center gap-2">✓ North Heights</div>
                  <div className="flex items-center gap-2">✓ South Point</div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-7">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Map Embed Placeholder */}
      <section className="h-[450px] bg-gray-200">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215152809572!2d-73.98784308459418!3d40.75797877932688!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1651859891823!5m2!1sen!2sus" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen={true} 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </div>
  );
};
