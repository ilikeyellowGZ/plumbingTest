
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, Mail, Clock, Menu, X, Facebook, Twitter, MapPin } from 'lucide-react';
import { BRAND } from '../constants';
import { Button } from './Button';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
    setIsMenuOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Bar - Hidden on mobile */}
      <div className="hidden md:block bg-slate-900 text-white py-2 text-sm">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex gap-6">
            <span className="flex items-center gap-2"><Clock size={14} className="text-red-500" /> 24/7 Emergency Service</span>
            <span className="flex items-center gap-2"><MapPin size={14} className="text-red-500" /> Serving {BRAND.city} & Surrounding Areas</span>
          </div>
          <div className="flex gap-4">
            <a href={`mailto:${BRAND.email}`} className="hover:text-red-400 transition-colors">{BRAND.email}</a>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <nav className="sticky top-0 z-50 bg-white shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex flex-col items-start">
              <span className="brand-font text-3xl font-black text-slate-900 leading-none">{BRAND.name}</span>
              <span className="text-[10px] font-bold text-red-600 tracking-[0.2em] leading-none uppercase">Plumbing & Drains</span>
            </Link>

            {/* Desktop Links */}
            <div className="hidden lg:flex items-center gap-8">
              <Link to="/" className="font-bold text-slate-700 hover:text-red-600 transition-colors uppercase text-sm">Home</Link>
              <Link to="/services" className="font-bold text-slate-700 hover:text-red-600 transition-colors uppercase text-sm">Services</Link>
              <Link to="/about" className="font-bold text-slate-700 hover:text-red-600 transition-colors uppercase text-sm">About Us</Link>
              <Link to="/news" className="font-bold text-slate-700 hover:text-red-600 transition-colors uppercase text-sm">News</Link>
              <Link to="/contact" className="font-bold text-slate-700 hover:text-red-600 transition-colors uppercase text-sm">Contact</Link>
              <div className="h-10 w-[1px] bg-gray-200"></div>
              <div className="flex flex-col items-end">
                <span className="text-xs font-bold text-gray-500 uppercase">Call Our 24/7 Hotline</span>
                <a href={`tel:${BRAND.phone}`} className="text-xl font-black text-red-600 hover:text-red-700">{BRAND.phone}</a>
              </div>
            </div>

            {/* Mobile Toggle */}
            <button 
              className="lg:hidden p-2 text-slate-900" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle Menu"
            >
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden absolute top-20 left-0 w-full bg-white border-b border-gray-200 shadow-xl p-4 flex flex-col gap-4 animate-in slide-in-from-top duration-300">
            <Link to="/" className="text-lg font-bold py-2 border-b border-gray-100 uppercase">Home</Link>
            <Link to="/services" className="text-lg font-bold py-2 border-b border-gray-100 uppercase">Services</Link>
            <Link to="/about" className="text-lg font-bold py-2 border-b border-gray-100 uppercase">About Us</Link>
            <Link to="/news" className="text-lg font-bold py-2 border-b border-gray-100 uppercase">News</Link>
            <Link to="/contact" className="text-lg font-bold py-2 border-b border-gray-100 uppercase">Contact</Link>
            <div className="py-4 text-center">
              <p className="text-xs font-bold text-gray-500 uppercase mb-2">24/7 Emergency Service</p>
              <a href={`tel:${BRAND.phone}`} className="text-3xl font-black text-red-600 block mb-4">{BRAND.phone}</a>
              <Button fullWidth onClick={() => window.location.href = '#/contact'}>Request A Quote</Button>
            </div>
          </div>
        )}
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            {/* Brand Info */}
            <div>
              <Link to="/" className="inline-flex flex-col items-start mb-6">
                <span className="brand-font text-3xl font-black text-white leading-none">{BRAND.name}</span>
                <span className="text-[10px] font-bold text-red-600 tracking-[0.2em] leading-none uppercase">Plumbing & Drains</span>
              </Link>
              <p className="text-gray-400 mb-6">
                Professional, licensed plumbing services for over {BRAND.yearsInBusiness} years. We pride ourselves on reliability and upfront pricing.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-600 transition-colors"><Facebook size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-600 transition-colors"><Twitter size={18} /></a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-bold uppercase mb-6 border-l-4 border-red-600 pl-3">Quick Links</h4>
              <ul className="space-y-4 text-gray-400 font-semibold">
                <li><Link to="/services" className="hover:text-red-500 transition-colors">Our Services</Link></li>
                <li><Link to="/about" className="hover:text-red-500 transition-colors">About the Company</Link></li>
                <li><Link to="/news" className="hover:text-red-500 transition-colors">Latest News & Tips</Link></li>
                <li><Link to="/contact" className="hover:text-red-500 transition-colors">Get a Free Quote</Link></li>
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-bold uppercase mb-6 border-l-4 border-red-600 pl-3">Our Services</h4>
              <ul className="space-y-4 text-gray-400 font-semibold">
                <li><Link to="/services" className="hover:text-red-500 transition-colors">Emergency Plumbing</Link></li>
                <li><Link to="/services" className="hover:text-red-500 transition-colors">Drain & Sewer Cleaning</Link></li>
                <li><Link to="/services" className="hover:text-red-500 transition-colors">Water Heater Repair</Link></li>
                <li><Link to="/services" className="hover:text-red-500 transition-colors">Commercial Plumbing</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-lg font-bold uppercase mb-6 border-l-4 border-red-600 pl-3">Get in Touch</h4>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <Phone size={20} className="text-red-600 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-gray-500 uppercase">Call 24/7</p>
                    <a href={`tel:${BRAND.phone}`} className="text-lg font-bold hover:text-red-500">{BRAND.phone}</a>
                  </div>
                </li>
                <li className="flex gap-3">
                  <Mail size={20} className="text-red-600 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-gray-500 uppercase">Email Us</p>
                    <a href={`mailto:${BRAND.email}`} className="text-sm font-semibold hover:text-red-500">{BRAND.email}</a>
                  </div>
                </li>
                <li className="flex gap-3">
                  <MapPin size={20} className="text-red-600 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-gray-500 uppercase">Our Office</p>
                    <p className="text-sm font-semibold text-gray-400">{BRAND.address}</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
            <p>© {new Date().getFullYear()} {BRAND.name} Services. All Rights Reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
