
import React, { useState } from 'react';
import { Button } from './Button';
import { CheckCircle } from 'lucide-react';

export const ContactForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return (
      <div className="bg-white p-8 rounded-lg shadow-xl text-center flex flex-col items-center justify-center min-h-[400px]">
        <CheckCircle className="text-green-500 w-16 h-16 mb-4" />
        <h3 className="text-2xl font-bold mb-2 uppercase">Request Received!</h3>
        <p className="text-gray-600 mb-6">Our team will call you within 15 minutes to confirm details.</p>
        <Button onClick={() => setSubmitted(false)}>Send Another Message</Button>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 md:p-8 rounded-lg shadow-xl border-t-4 border-red-600">
      <h3 className="text-2xl font-bold mb-1 uppercase">Request a Free Quote</h3>
      <p className="text-sm text-gray-500 mb-6 uppercase tracking-wider font-bold">Fast response guaranteed</p>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Full Name *</label>
            <input 
              required
              type="text" 
              placeholder="John Doe"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Phone Number *</label>
            <input 
              required
              type="tel" 
              placeholder="(555) 000-0000"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Service Needed</label>
          <select className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none appearance-none">
            <option>Emergency Repair</option>
            <option>Drain Cleaning</option>
            <option>Water Heater Service</option>
            <option>Leaking Pipes</option>
            <option>Commercial Plumbing</option>
            <option>Other</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase text-slate-700 mb-1">Brief Description of Issue</label>
          <textarea 
            rows={4}
            placeholder="Tell us what's happening..."
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none"
          ></textarea>
        </div>

        <Button 
          type="submit" 
          fullWidth 
          size="lg" 
          disabled={loading}
        >
          {loading ? 'Processing...' : 'Send Request Now'}
        </Button>
        <p className="text-[10px] text-center text-gray-400 mt-4 uppercase font-bold">
          Your privacy is safe. We never share your details.
        </p>
      </form>
    </div>
  );
};
